package com.result_publishing_app.application.config;


import com.result_publishing_app.application.exceptions.InvalidUsernameException;
import com.result_publishing_app.application.model.User;
import com.result_publishing_app.application.model.UserRole;
import com.result_publishing_app.application.model.professor.Professor;
import com.result_publishing_app.application.model.student.Student;
import com.result_publishing_app.application.repository.StudentRepository;
import com.result_publishing_app.application.repository.UserRepository;
import com.result_publishing_app.application.service.ProfessorService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class FacultyUserDetailsService implements UserDetailsService {

    private final StudentRepository studentRepository;
    @Value("${system.authentication.password}")
    String systemAuthenticationPassword;

    final UserRepository userRepository;

    final ProfessorService professorService;

    final PasswordEncoder passwordEncoder;

    public FacultyUserDetailsService(UserRepository userRepository,
                                     ProfessorService professorService,
                                     StudentRepository studentRepository,
                                     PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.professorService = professorService;
        this.passwordEncoder = passwordEncoder;
        this.studentRepository = studentRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findById(username).orElse(null);
        if (user == null) {
            Student student = studentRepository.findById(username).orElseThrow(InvalidUsernameException::new);
            User user1 = new User();
            user1.setId(username);
            user1.setRole(UserRole.STUDENT);
            return new FacultyUserDetails(user1, student, passwordEncoder.encode(systemAuthenticationPassword));
        } else if (user.getRole().isProfessor()) {
            Professor professor = professorService.getProfessorById(username);
            return new FacultyUserDetails(user, professor, passwordEncoder.encode(systemAuthenticationPassword));
        } else {
            return new FacultyUserDetails(user, passwordEncoder.encode(systemAuthenticationPassword));
        }
    }
}
