package com.result_publishing_app.application.exceptions;

public class InvalidUsernameException extends RuntimeException {
}
