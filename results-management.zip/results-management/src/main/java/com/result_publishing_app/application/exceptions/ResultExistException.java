package com.result_publishing_app.application.exceptions;

import com.result_publishing_app.application.model.course.Course;
import com.result_publishing_app.application.model.yearExamSession.YearExamSession;

public class ResultExistException extends RuntimeException{
    public ResultExistException(YearExamSession session, Course course) {
        super(String.format("Result for session %s and courseGroup %s-%s already exists",
                session.getName(),
                course.getId(),
                course.getProfessors()));
    }
}
