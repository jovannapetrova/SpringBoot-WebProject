package com.result_publishing_app.application.exceptions;

public class SubjectNotFoundException extends RuntimeException {
    public SubjectNotFoundException(String str) {
        super(str);
    }
}
