package com.result_publishing_app.application.model.DTO;

import com.result_publishing_app.application.model.professor.Professor;

import java.time.LocalDate;

public class LateResultInfo {
    private Professor professor;
    private String courseName;
    private String sessionName;
    private LocalDate examDate;
    private LocalDate deadline;
    private LocalDate uploadedDate;

    public LocalDate getExamDate() {
        return examDate;
    }

    public void setExamDate(LocalDate examDate) {
        this.examDate = examDate;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public LocalDate getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(LocalDate uploadedDate) {
        this.uploadedDate = uploadedDate;
    }

    public LateResultInfo() {
//        this.professor = professor;
//        this.courseName = courseName;
//        this.sessionName = sessionName;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getSessionName() {
        return sessionName;
    }

    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

// Constructors, getters, setters
}
