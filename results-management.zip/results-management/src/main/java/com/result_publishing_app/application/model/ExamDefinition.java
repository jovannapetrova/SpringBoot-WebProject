package com.result_publishing_app.application.model;


import com.result_publishing_app.application.model.entity.TrackedHistoryEntity;
import com.result_publishing_app.application.model.enums.ExamSession;
import com.result_publishing_app.application.model.enums.ExamType;
import com.result_publishing_app.application.model.subject.JoinedSubject;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class ExamDefinition extends TrackedHistoryEntity {

    // WP-JUNE-LAB
    @Id
    private String id;

    @ManyToOne
    JoinedSubject subject;

    @Enumerated(EnumType.STRING)
    private ExamSession examSession;

    private Long durationMinutes;

    @Enumerated(EnumType.STRING)
    private ExamType type;

    private String note;

}

