package com.result_publishing_app.application.model.course;

import com.result_publishing_app.application.model.room.Room;
import com.result_publishing_app.application.model.schedule.StudentGroup;
import com.result_publishing_app.application.model.semester.Semester;
import com.result_publishing_app.application.model.subject.JoinedSubject;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
public class Course {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne
    private Semester semester;

    @ManyToOne
    private JoinedSubject joinedSubject;


    private String professors;

    private String assistants;

    @ManyToMany
    private List<StudentGroup> studentGroups;

    @ManyToMany
    private List<Room> rooms;

    private Integer numberOfFirstEnrollments;

    private Integer numberOfReEnrollments;

    private Float groupPortion = 1.0F;

    private String groups;

    private Boolean english = false;

    public Integer getTotalStudents() {
        return Optional.ofNullable(numberOfFirstEnrollments).orElse(0) +
                Optional.ofNullable(numberOfReEnrollments).orElse(0);
    }
}


