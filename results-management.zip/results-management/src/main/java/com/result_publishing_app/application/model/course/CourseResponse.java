package com.result_publishing_app.application.model.course;

import lombok.*;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CourseResponse {

    private Long id;

    private String year;

    private String subjectId;

    private Set<String> professorIds;

    private Set<String> studentIndexes;

    private Set<String> sessionNames;
}
