package com.result_publishing_app.application.model.enums;

public enum AppRole {
    PROFESSOR, ADMIN, STUDENT;


    public String roleName() {
        return "ROLE_" + this.name();
    }
}
