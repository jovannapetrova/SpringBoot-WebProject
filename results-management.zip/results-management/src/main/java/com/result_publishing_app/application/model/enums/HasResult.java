package com.result_publishing_app.application.model.enums;

import java.util.Arrays;

public enum HasResult {
    Any,
    Yes,
    No;

    public static String[] getAll(){
        return Arrays.stream(HasResult.values()).map(Enum::name).toArray(String[]::new);
    }
}
