package com.result_publishing_app.application.model.enums;

public enum SemesterState {

    FINISHED(false),
    STARTED(true),
    SCHEDULE_PREPARATION(true),
    TEACHER_SUBJECT_ALLOCATION(true),
    STUDENTS_ENROLLMENT(true),
    DATA_COLLECTION(true),
    INACTIVE(false);

    private final boolean active;

    SemesterState(boolean active) {
        this.active = active;
    }
}
