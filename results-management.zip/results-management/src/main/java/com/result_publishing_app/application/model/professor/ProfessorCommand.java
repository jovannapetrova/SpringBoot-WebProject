package com.result_publishing_app.application.model.professor;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProfessorCommand extends ProfessorResponse {
}
