package com.result_publishing_app.application.model.results;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResultsCommand extends ResultsResponse {
}
