package com.result_publishing_app.application.model.subject;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SubjectCommand extends SubjectResponse {

}
