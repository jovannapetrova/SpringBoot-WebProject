package com.result_publishing_app.application.repository;


import com.result_publishing_app.application.model.course.Course;
import com.result_publishing_app.application.model.professor.Professor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRepository extends JpaSpecificationRepository<Course, Long> {

    Optional<Course> findCourseById(Long courseId);

    List<Course> findAllByProfessorsLike(String professors);

    List<Course> findAllBySemesterYear(String year);

    List<Course> findAllByProfessorsContaining(String professor);

}
