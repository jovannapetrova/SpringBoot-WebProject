package com.result_publishing_app.application.repository;


import com.result_publishing_app.application.model.course.Course;
import com.result_publishing_app.application.model.professor.Professor;
import com.result_publishing_app.application.model.results.Results;
import com.result_publishing_app.application.model.subject.JoinedSubject;
import com.result_publishing_app.application.model.yearExamSession.YearExamSession;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ResultsRepository extends JpaSpecificationRepository<Results, Long> {

    Optional<Results> findBySessionAndJoinedSubject(YearExamSession session, JoinedSubject joinedSubject);

    Optional<Results> findByJoinedSubjectAbbreviationAndSessionNameAndResultTypeAndUploadedBy(String abbreviation, String sessionName, String ResultType, Professor professor);

    List<Results> findByUploadedBy(Professor professor);

    //List<Results> findBySession(YearExamSession session);

    //List<Results> findByUploadedAtIsNull();

    //List<Results> findByUploadedAtBeforeAndSession(LocalDateTime date, YearExamSession session);
}