package com.result_publishing_app.application.repository;


import com.result_publishing_app.application.model.student.Student;
import com.result_publishing_app.application.model.studentCourses.StudentCourses;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentInCourses extends JpaRepository<StudentCourses, Long> {
    List<StudentCourses> findByStudent(Student student);

}
