package com.result_publishing_app.application.repository;

import com.result_publishing_app.application.model.subjectExam.SubjectExam;
import com.result_publishing_app.application.model.yearExamSession.YearExamSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SubjectExamRepository extends JpaRepository<SubjectExam, String> {

        Optional<SubjectExam> findByDefinition_Subject_AbbreviationAndSession(String abbreviation, YearExamSession session);


}
