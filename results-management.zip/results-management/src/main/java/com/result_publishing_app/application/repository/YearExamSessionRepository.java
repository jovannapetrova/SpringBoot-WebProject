package com.result_publishing_app.application.repository;

import com.result_publishing_app.application.model.yearExamSession.YearExamSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface YearExamSessionRepository extends JpaRepository<YearExamSession, String> {

    Optional<YearExamSession> findByName(String name);

    /*Optional<Session> findByName(String string);

    boolean existsByName(String name);

    boolean existsByDueDateAndName(LocalDate dueDate,String name);

    List<Session> findByCourses_Id(String id);*/
}
