package com.result_publishing_app.application.service;

import com.result_publishing_app.application.model.course.Course;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CourseService {

    List<Course> findAll();

    Course findById(Long courseId);

    List<Course> findByYear(String year);

    List<Course> findByProfessorId(String professorId);

    Page<Course> list(Integer pageNum, Integer results);
    Page<Course> findByProfessorIdPaginated(String professorId, Integer pageNum, Integer size);


}
