package com.result_publishing_app.application.service;


import com.result_publishing_app.application.exceptions.ProfessorNotFoundException;
import com.result_publishing_app.application.model.DTO.LateResultInfo;
import com.result_publishing_app.application.model.professor.Professor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ProfessorService {
    List<Professor> findAll();

    Professor findById(String professor);

    Professor getProfessorById(String id) throws ProfessorNotFoundException;
    List<Professor> findProfessorsWithoutResults();
    //List<Professor> findProfessorsWithLateResults();
     List<LateResultInfo> findLateResultsInfo();
}
