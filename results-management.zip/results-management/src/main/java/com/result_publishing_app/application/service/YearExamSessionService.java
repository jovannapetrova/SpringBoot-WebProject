package com.result_publishing_app.application.service;


import com.result_publishing_app.application.model.course.Course;
import com.result_publishing_app.application.model.yearExamSession.YearExamSession;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;


public interface YearExamSessionService {

    Optional<YearExamSession> findByName(String name);

    List<YearExamSession> findAll();

    Page<YearExamSession> findAllWithPaginationAndSorting(Integer page, Integer size, String sortBy);

    void createResultForExamSessionAndCourseGroup(YearExamSession session, Course course);

    void initializeExamSession(String name);

}
