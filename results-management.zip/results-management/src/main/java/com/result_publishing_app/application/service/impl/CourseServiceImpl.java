package com.result_publishing_app.application.service.impl;

import com.result_publishing_app.application.model.course.Course;
import com.result_publishing_app.application.repository.CourseRepository;
import com.result_publishing_app.application.service.CourseService;
import com.result_publishing_app.application.specifications.FieldFilterSpecification;
import jakarta.persistence.criteria.Predicate;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;


    public List<Course> findAll() {
        return courseRepository.findAll();
    }

    public Course findById(Long courseId) {
        return courseRepository.findCourseById(courseId).orElse(null);
    }

    public List<Course> findByYear(String year) {
        return courseRepository.findAllBySemesterYear(year);
    }

    public List<Course> findByProfessorId(String professorId) {
        return courseRepository.findAllByProfessorsContaining(professorId);
    }

    public Page<Course> list(Integer pageNum, Integer results) {
        return courseRepository.findAll(PageRequest.of(pageNum - 1, results));
    }

    @Override
    public Page<Course> findByProfessorIdPaginated(String professorId, Integer pageNum, Integer size) {
        Specification<Course> specification = (root, criteriaQuery, criteriaBuilder) -> {
            Predicate p1 =  criteriaBuilder.like(root.get("professors"), "%" + professorId + "%");
            Predicate p2 = criteriaBuilder.like(root.get("assistants"),"%" + professorId + "%");
            return criteriaBuilder.or(p1,p2);
        };
        return courseRepository.findAll(specification, PageRequest.of(pageNum - 1, size));
    }
}
