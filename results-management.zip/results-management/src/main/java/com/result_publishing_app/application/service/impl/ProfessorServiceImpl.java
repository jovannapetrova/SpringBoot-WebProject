package com.result_publishing_app.application.service.impl;

import com.result_publishing_app.application.exceptions.ProfessorNotFoundException;
import com.result_publishing_app.application.model.DTO.LateResultInfo;
import com.result_publishing_app.application.model.enums.ExamSession;
import com.result_publishing_app.application.model.professor.Professor;
import com.result_publishing_app.application.model.results.Results;
import com.result_publishing_app.application.model.subjectExam.SubjectExam;
import com.result_publishing_app.application.model.yearExamSession.YearExamSession;
import com.result_publishing_app.application.repository.ProfessorRepository;
import com.result_publishing_app.application.repository.ResultsRepository;
import com.result_publishing_app.application.repository.SubjectExamRepository;
import com.result_publishing_app.application.service.ProfessorService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class ProfessorServiceImpl implements ProfessorService {

    private ProfessorRepository professorRepository;
    private ResultsRepository resultsRepository;
    @Autowired
    private SubjectExamRepository subjectExamRepository;
    public List<Professor> findAll() {
        return professorRepository.findAll()
                .stream().sorted(Comparator.comparing(Professor::getId)).collect(Collectors.toList());
    }

    public Professor findById(String professor) {
        return professorRepository.findById(professor).orElse(null);
    }

    public Professor getProfessorById(String id) throws ProfessorNotFoundException {
        return professorRepository.findById(id)
                .orElseThrow(() -> new ProfessorNotFoundException("Professor with id " + id + " doesn't exist"));
    }
    @Override
    public List<Professor> findProfessorsWithoutResults() {
        List<Professor> professors = professorRepository.findAll();
        System.out.println(professors);
        return professors.stream()
                .filter(professor -> resultsRepository.findByUploadedBy(professor).isEmpty())
                .toList();
    }
    //se vlecat site rezultati za odreden prof... ako e prazna listata na rezultati za toj prof znaci nema objaveno vo nikoja sesija

    @Override
    public List<LateResultInfo> findLateResultsInfo() {
        List<LateResultInfo> lateResults = new ArrayList<>();

        for (Professor professor : professorRepository.findAll()) {
            List<Results> results = resultsRepository.findByUploadedBy(professor);
            for (Results result : results) {
                if (result.getUploadedAt() == null) continue;

                String subjectAbbreviation = result.getJoinedSubject().getAbbreviation();
                YearExamSession session = result.getSession();

                SubjectExam subjectExam = subjectExamRepository
                        .findByDefinition_Subject_AbbreviationAndSession(subjectAbbreviation, session)
                        .orElse(null);

                if (subjectExam == null || subjectExam.getFromTime() == null) continue;

                LocalDate examDate = subjectExam.getFromTime().toLocalDate();
                LocalDate deadline;

                if (session.getSession() == ExamSession.FIRST_MIDTERM
                        || session.getSession() == ExamSession.SECOND_MIDTERM) {
                    deadline = examDate.plusWeeks(2);
                } else {
                    deadline = examDate.plusMonths(1);
                }

                if (result.getUploadedAt().toLocalDate().isAfter(deadline)) {
                    LateResultInfo info = new LateResultInfo();
                    info.setProfessor(professor);
                    info.setCourseName(result.getJoinedSubject().getName());
                    info.setSessionName(session.getSession().name());
                    info.setExamDate(examDate);
                    info.setDeadline(deadline);
                    info.setUploadedDate(result.getUploadedAt().toLocalDate());
                    lateResults.add(info);
                }
            }
        }

        return lateResults;
    }

//    @Override
//    public List<LateResultInfo> findLateResultsInfo() {
//        List<LateResultInfo> lateResults = new ArrayList<>();
//
//        for (Professor professor : professorRepository.findAll()) {
//            List<Results> results = resultsRepository.findByUploadedBy(professor);
//            for (Results result : results) {
//                if (result.getUploadedAt() == null) continue;
//
//                YearExamSession session = result.getSession();
//                LocalDate examDate = session.getSessionEnd();
//                LocalDate deadline;
//
//                if (session.getSession() == ExamSession.FIRST_MIDTERM || session.getSession() == ExamSession.SECOND_MIDTERM) {
//                    deadline = examDate.plusWeeks(2);
//                } else {
//                    deadline = examDate.plusMonths(1);
//                }
//
//                if (result.getUploadedAt().toLocalDate().isAfter(deadline)) {
//                    LateResultInfo info = new LateResultInfo();
//                    info.setProfessor(professor);
//                    info.setCourseName(result.getJoinedSubject().getName());
//                    info.setSessionName(session.getSession().name());
//                    info.setExamDate(examDate);
//                    info.setDeadline(deadline);
//                    info.setUploadedDate(result.getUploadedAt().toLocalDate());
//                    lateResults.add(info);
//                }
//            }
//        }
//
//        return lateResults;
//    }





}
