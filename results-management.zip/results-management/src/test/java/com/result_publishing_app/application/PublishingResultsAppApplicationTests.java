package com.result_publishing_app.application;

//@SpringBootTest
//class PublishingResultsAppApplicationTests {
//
//    @Test
//    void contextLoads() {
//    }
//
//}
